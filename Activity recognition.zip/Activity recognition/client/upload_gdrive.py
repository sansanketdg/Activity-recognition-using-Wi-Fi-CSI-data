import os

os.system('gdrive update 0B7IDjH2Kr7A-OHloUHgyaEFrdmc gdrive_data/sample_data.csv')